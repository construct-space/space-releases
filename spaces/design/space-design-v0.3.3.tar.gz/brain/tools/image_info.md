---
id: image_info
name: Image Info
description: Get dimensions, format, and metadata of an image file
parameters:
  - name: path
    type: string
    description: Path to the image file
    required: true
command: |
  FILE={{path}}

  if [ ! -f "$FILE" ]; then
    echo "File not found: $FILE"
    exit 1
  fi

  # Try sips (macOS built-in) first
  if command -v sips &>/dev/null; then
    echo "=== Image Info ==="
    sips -g all "$FILE" 2>/dev/null | grep -E "pixelWidth|pixelHeight|format|space|dpiWidth|dpiHeight|hasAlpha|bitsPerSample"
    echo ""

    # File size
    SIZE=$(stat -f%z "$FILE" 2>/dev/null || stat -c%s "$FILE" 2>/dev/null)
    if [ -n "$SIZE" ]; then
      if [ "$SIZE" -gt 1048576 ]; then
        echo "File size: $(echo "scale=1; $SIZE/1048576" | bc)MB"
      elif [ "$SIZE" -gt 1024 ]; then
        echo "File size: $(echo "scale=1; $SIZE/1024" | bc)KB"
      else
        echo "File size: ${SIZE}B"
      fi
    fi

  # Try file command as fallback
  elif command -v file &>/dev/null; then
    file "$FILE"
  else
    echo "No image analysis tool available (sips or file)"
    exit 1
  fi
workdir: project
timeout: 10
confirm: false
---

Use this tool to check image dimensions, format, and metadata before placing images in designs. Useful for determining correct aspect ratios for image elements. Uses macOS built-in sips.
