---
id: image_resize
name: Resize Image
description: Resize, crop, or convert image files
parameters:
  - name: input
    type: string
    description: Path to the input image
    required: true
  - name: output
    type: string
    description: Path for the output image (format inferred from extension)
    required: true
  - name: width
    type: string
    description: Target width in pixels
    required: false
  - name: height
    type: string
    description: Target height in pixels
    required: false
  - name: scale
    type: string
    description: Scale factor (e.g. 0.5 for half size, 2 for double)
    required: false
command: |
  INPUT={{input}}
  OUTPUT={{output}}
  WIDTH={{width}}
  HEIGHT={{height}}
  SCALE={{scale}}

  if [ ! -f "$INPUT" ]; then
    echo "Input file not found: $INPUT"
    exit 1
  fi

  # Use sips (macOS built-in)
  if command -v sips &>/dev/null; then
    # Copy to output first
    cp "$INPUT" "$OUTPUT"

    if [ -n "$SCALE" ]; then
      # Get current dimensions and scale
      CUR_W=$(sips -g pixelWidth "$OUTPUT" | tail -1 | awk '{print $2}')
      CUR_H=$(sips -g pixelHeight "$OUTPUT" | tail -1 | awk '{print $2}')
      WIDTH=$(python3 -c "print(int($CUR_W * $SCALE))")
      HEIGHT=$(python3 -c "print(int($CUR_H * $SCALE))")
    fi

    ARGS=""
    if [ -n "$WIDTH" ] && [ -n "$HEIGHT" ]; then
      sips --resampleHeightWidth "$HEIGHT" "$WIDTH" "$OUTPUT" >/dev/null 2>&1
    elif [ -n "$WIDTH" ]; then
      sips --resampleWidth "$WIDTH" "$OUTPUT" >/dev/null 2>&1
    elif [ -n "$HEIGHT" ]; then
      sips --resampleHeight "$HEIGHT" "$OUTPUT" >/dev/null 2>&1
    fi

    # Handle format conversion based on output extension
    EXT="${OUTPUT##*.}"
    case "$EXT" in
      jpg|jpeg) sips -s format jpeg "$OUTPUT" --out "$OUTPUT" >/dev/null 2>&1 ;;
      png) sips -s format png "$OUTPUT" --out "$OUTPUT" >/dev/null 2>&1 ;;
      webp) sips -s format com.google.webp "$OUTPUT" --out "$OUTPUT" >/dev/null 2>&1 ;;
    esac

    echo "=== Result ==="
    sips -g pixelWidth -g pixelHeight -g format "$OUTPUT" 2>/dev/null
    SIZE=$(stat -f%z "$OUTPUT" 2>/dev/null)
    echo "File size: $(echo "scale=1; $SIZE/1024" | bc)KB"
    echo "Output: $OUTPUT"
  else
    echo "sips not available (macOS only)"
    exit 1
  fi
workdir: project
timeout: 30
confirm: false
---

Use this tool to resize images for designs. Can resize by width, height, or scale factor. Supports format conversion between JPEG, PNG, and WebP via output file extension. Uses macOS built-in sips — no external dependencies.
