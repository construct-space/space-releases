---
id: contrast_check
name: Contrast Check
description: Check WCAG color contrast ratio between foreground and background colors
parameters:
  - name: foreground
    type: string
    description: "Foreground (text) color as hex (e.g. #333333)"
    required: true
  - name: background
    type: string
    description: "Background color as hex (e.g. #FFFFFF)"
    required: true
command: |
  FG={{foreground}}
  BG={{background}}

  # Strip # prefix
  FG=$(echo "$FG" | tr -d '#')
  BG=$(echo "$BG" | tr -d '#')

  # Expand 3-digit hex to 6-digit
  if [ ${#FG} -eq 3 ]; then
    FG="${FG:0:1}${FG:0:1}${FG:1:1}${FG:1:1}${FG:2:1}${FG:2:1}"
  fi
  if [ ${#BG} -eq 3 ]; then
    BG="${BG:0:1}${BG:0:1}${BG:1:1}${BG:1:1}${BG:2:1}${BG:2:1}"
  fi

  # Parse RGB values and calculate relative luminance + contrast ratio
  python3 -c "
  import sys

  def hex_to_rgb(h):
      return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

  def srgb_to_linear(c):
      c = c / 255.0
      return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

  def relative_luminance(r, g, b):
      return 0.2126 *srgb_to_linear(r) + 0.7152* srgb_to_linear(g) + 0.0722 * srgb_to_linear(b)

  fg = hex_to_rgb('$FG')
  bg = hex_to_rgb('$BG')

  l1 = relative_luminance(*fg)
  l2 = relative_luminance(*bg)

  lighter = max(l1, l2)
  darker = min(l1, l2)
  ratio = (lighter + 0.05) / (darker + 0.05)

  print(f'Foreground: #{\"$FG\".upper()} → rgb({fg[0]}, {fg[1]}, {fg[2]})')
  print(f'Background: #{\"$BG\".upper()} → rgb({bg[0]}, {bg[1]}, {bg[2]})')
  print(f'')
  print(f'Contrast Ratio: {ratio:.2f}:1')
  print(f'')
  print(f'WCAG AA  Normal text (≥4.5:1): {\"✓ PASS\" if ratio >= 4.5 else \"✗ FAIL\"}')
  print(f'WCAG AA  Large text  (≥3.0:1): {\"✓ PASS\" if ratio >= 3.0 else \"✗ FAIL\"}')
  print(f'WCAG AAA Normal text (≥7.0:1): {\"✓ PASS\" if ratio >= 7.0 else \"✗ FAIL\"}')
  print(f'WCAG AAA Large text  (≥4.5:1): {\"✓ PASS\" if ratio >= 4.5 else \"✗ FAIL\"}')

  if ratio < 4.5:
      print(f'')
      print(f'⚠ Does not meet WCAG AA for normal text.')
      print(f'  Minimum ratio needed: 4.5:1 (current: {ratio:.2f}:1)')
  "
workdir: home
timeout: 10
confirm: false
---

Use this tool to verify color accessibility. Always check contrast when the user picks text colors against backgrounds. WCAG AA requires 4.5:1 for normal text and 3:1 for large text (18px+ bold or 24px+ regular). Report the results and suggest alternatives if contrast is insufficient.
