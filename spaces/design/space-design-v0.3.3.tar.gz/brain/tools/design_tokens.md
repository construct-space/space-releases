---
id: design_tokens
name: Design Tokens
description: Export design system tokens (colors, typography, spacing) as CSS variables or JSON
parameters:
  - name: format
    type: string
    description: Output format
    required: true
    enum: [css, json, tailwind]
  - name: colors
    type: string
    description: "Comma-separated hex colors with names (e.g. 'primary:#3B82F6,secondary:#10B981,accent:#F59E0B')"
    required: false
  - name: font_family
    type: string
    description: Primary font family (default Inter)
    required: false
  - name: base_size
    type: string
    description: Base font size in px (default 16)
    required: false
  - name: spacing_unit
    type: string
    description: Base spacing unit in px (default 8)
    required: false
command: |
  FORMAT={{format}}
  COLORS={{colors}}
  FONT={{font_family}}
  BASE_SIZE={{base_size}}
  SPACING={{spacing_unit}}

  [ -z "$FONT" ] && FONT="Inter"
  [ -z "$BASE_SIZE" ] && BASE_SIZE=16
  [ -z "$SPACING" ] && SPACING=8

  python3 -c "
  import json

  format_type = '$FORMAT'
  font = '$FONT'
  base_size = int('$BASE_SIZE')
  spacing = int('$SPACING')

  # Parse colors
  colors = {}
  color_str = '''$COLORS'''
  if color_str:
      for pair in color_str.split(','):
          pair = pair.strip()
          if ':' in pair:
              name, val = pair.split(':', 1)
              colors[name.strip()] = val.strip()

  if not colors:
      colors = {
          'primary': '#3B82F6',
          'secondary': '#6B7280',
          'accent': '#F59E0B',
          'success': '#10B981',
          'warning': '#F97316',
          'error': '#EF4444',
          'background': '#FFFFFF',
          'surface': '#F9FAFB',
          'text': '#111827',
          'text-secondary': '#6B7280',
          'border': '#E5E7EB',
      }

  # Font scale (major third 1.25)
  font_scale = {
      'xs': round(base_size *0.75),
      'sm': round(base_size* 0.875),
      'base': base_size,
      'lg': round(base_size *1.125),
      'xl': round(base_size* 1.25),
      '2xl': round(base_size *1.5),
      '3xl': round(base_size* 1.875),
      '4xl': round(base_size *2.25),
      '5xl': round(base_size* 3),
  }

  # Spacing scale
  spacing_scale = {str(i): spacing * i for i in [0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24]}

  # Radius scale
  radius_scale = {'none': 0, 'sm': 2, 'md': 6, 'lg': 8, 'xl': 12, '2xl': 16, 'full': 9999}

  if format_type == 'css':
      print(':root {')
      print('  /*Colors */')
      for name, val in colors.items():
          print(f'  --color-{name}: {val};')
      print()
      print('  /* Typography */')
      print(f'  --font-family: \"{font}\", system-ui, sans-serif;')
      for name, size in font_scale.items():
          print(f'  --font-size-{name}: {size}px;')
      print()
      print('  /* Spacing */')
      for name, val in spacing_scale.items():
          print(f'  --spacing-{name}: {val}px;')
      print()
      print('  /* Border Radius*/')
      for name, val in radius_scale.items():
          print(f'  --radius-{name}: {val}px;')
      print('}')

  elif format_type == 'json':
      tokens = {
          'colors': colors,
          'typography': {
              'fontFamily': f'\"{font}\", system-ui, sans-serif',
              'fontSize': {k: f'{v}px' for k, v in font_scale.items()},
          },
          'spacing': {k: f'{v}px' for k, v in spacing_scale.items()},
          'borderRadius': {k: f'{v}px' for k, v in radius_scale.items()},
      }
      print(json.dumps(tokens, indent=2))

  elif format_type == 'tailwind':
      print('// tailwind.config.js extend')
      print('module.exports = {')
      print('  theme: {')
      print('    extend: {')
      print('      colors: {')
      for name, val in colors.items():
          print(f'        \"{name}\": \"{val}\",')
      print('      },')
      print('      fontFamily: {')
      print(f'        sans: [\"{font}\", \"system-ui\", \"sans-serif\"],')
      print('      },')
      print('    },')
      print('  },')
      print('}')
  "
workdir: project
timeout: 10
confirm: false
---

Use this tool when the user asks to export design tokens, create a design system, or generate CSS/Tailwind config from their design colors and typography choices. Can output CSS custom properties, JSON tokens, or Tailwind config. Use the generated tokens to maintain consistency across designs.
