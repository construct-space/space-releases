---
id: color_palette
name: Color Palette
description: Generate color palettes — harmonies, shades, or from a base color
parameters:
  - name: base_color
    type: string
    description: "Base color as hex (e.g. #3B82F6)"
    required: true
  - name: mode
    type: string
    description: Palette generation mode
    required: false
    enum: [complementary, analogous, triadic, split-complementary, shades, tints, full]
command: |
  BASE={{base_color}}
  MODE={{mode}}

  if [ -z "$MODE" ]; then
    MODE="full"
  fi

  # Strip # prefix
  BASE=$(echo "$BASE" | tr -d '#')

  python3 -c "
  import colorsys

  def hex_to_hsl(h):
      r, g, b = int(h[0:2],16)/255, int(h[2:4],16)/255, int(h[4:6],16)/255
      h2, l, s = colorsys.rgb_to_hls(r, g, b)
      return h2*360, s*100, l*100

  def hsl_to_hex(h, s, l):
      h2, s2, l2 = h/360, s/100, l/100
      r, g, b = colorsys.hls_to_rgb(h2, l2, s2)
      return '#{:02X}{:02X}{:02X}'.format(int(r*255), int(g*255), int(b*255))

  base = '$BASE'
  mode = '$MODE'
  h, s, l = hex_to_hsl(base)

  print(f'Base: #{base.upper()} (H:{h:.0f} S:{s:.0f}% L:{l:.0f}%)')
  print()

  def show(label, colors):
      print(f'=== {label} ===')
      for name, hex_val in colors:
          print(f'  {name}: {hex_val}')
      print()

  if mode in ('complementary', 'full'):
      show('Complementary', [
          ('Base', hsl_to_hex(h, s, l)),
          ('Complement', hsl_to_hex((h+180)%360, s, l)),
      ])

  if mode in ('analogous', 'full'):
      show('Analogous', [
          ('Left 30°', hsl_to_hex((h-30)%360, s, l)),
          ('Base', hsl_to_hex(h, s, l)),
          ('Right 30°', hsl_to_hex((h+30)%360, s, l)),
      ])

  if mode in ('triadic', 'full'):
      show('Triadic', [
          ('Base', hsl_to_hex(h, s, l)),
          ('120°', hsl_to_hex((h+120)%360, s, l)),
          ('240°', hsl_to_hex((h+240)%360, s, l)),
      ])

  if mode in ('split-complementary', 'full'):
      show('Split-Complementary', [
          ('Base', hsl_to_hex(h, s, l)),
          ('Split 1', hsl_to_hex((h+150)%360, s, l)),
          ('Split 2', hsl_to_hex((h+210)%360, s, l)),
      ])

  if mode in ('shades', 'full'):
      shades = [(f'{int(l2)}%', hsl_to_hex(h, s, l2)) for l2 in [95, 85, 70, 55, 40, 25, 15, 5]]
      show('Shades (light → dark)', shades)

  if mode in ('tints', 'full'):
      tints = [(f'S:{int(s2)}%', hsl_to_hex(h, s2, l)) for s2 in [100, 80, 60, 40, 20, 10]]
      show('Saturation Scale', tints)

  if mode == 'full':
      print('=== Suggested UI Palette ===')
      print(f'  Primary:    {hsl_to_hex(h, s, l)}')
      print(f'  Primary-50: {hsl_to_hex(h, min(s,30), 95)}')
      print(f'  Primary-100:{hsl_to_hex(h, min(s,40), 90)}')
      print(f'  Primary-200:{hsl_to_hex(h, min(s,50), 80)}')
      print(f'  Primary-300:{hsl_to_hex(h, s*0.8, 65)}')
      print(f'  Primary-400:{hsl_to_hex(h, s*0.9, 55)}')
      print(f'  Primary-500:{hsl_to_hex(h, s, l)}')
      print(f'  Primary-600:{hsl_to_hex(h, s, l*0.8)}')
      print(f'  Primary-700:{hsl_to_hex(h, s, l*0.6)}')
      print(f'  Primary-800:{hsl_to_hex(h, s*0.9, l*0.4)}')
      print(f'  Primary-900:{hsl_to_hex(h, s*0.8, l*0.25)}')
  "
workdir: home
timeout: 10
confirm: false
---

Use this tool when the user asks about colors, palettes, or color schemes. Generate harmonious palettes from a base color. The "full" mode (default) generates all harmony types plus a Tailwind-style 50-900 scale suitable for UI design. Use the results to inform fill colors in create_design_element and create_ui_screen.
