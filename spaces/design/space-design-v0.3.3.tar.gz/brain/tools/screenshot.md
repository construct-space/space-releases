---
id: screenshot
name: Screenshot URL
description: Capture a screenshot of a URL for design reference
parameters:
  - name: url
    type: string
    description: URL to screenshot
    required: true
  - name: output
    type: string
    description: Output file path (default screenshot.png in project root)
    required: false
  - name: width
    type: string
    description: Viewport width (default 1440)
    required: false
  - name: height
    type: string
    description: Viewport height (default 900)
    required: false
  - name: full_page
    type: string
    description: Capture full scrollable page
    required: false
    enum: ["true", "false"]
command: |
  URL={{url}}
  OUTPUT={{output}}
  WIDTH={{width}}
  HEIGHT={{height}}
  FULL={{full_page}}

  [ -z "$WIDTH" ] && WIDTH=1440
  [ -z "$HEIGHT" ] && HEIGHT=900
  [ -z "$OUTPUT" ] && OUTPUT="screenshot.png"

  # Try playwright first (most reliable)
  if command -v npx &>/dev/null && npx playwright --version &>/dev/null 2>&1; then
    FULL_FLAG=""
    [ "$FULL" = "true" ] && FULL_FLAG="fullPage: true,"

    node -e "
      const { chromium } = require('playwright');
      (async () => {
        const browser = await chromium.launch();
        const page = await browser.newPage({ viewport: { width: $WIDTH, height: $HEIGHT } });
        await page.goto('$URL', { waitUntil: 'networkidle', timeout: 30000 });
        await page.screenshot({ path: '$OUTPUT', $FULL_FLAG });
        await browser.close();
        console.log('Screenshot saved to $OUTPUT');
      })().catch(e => { console.error(e.message); process.exit(1); });
    " 2>&1
  # Try puppeteer
  elif command -v node &>/dev/null && node -e "require('puppeteer')" 2>/dev/null; then
    FULL_FLAG="false"
    [ "$FULL" = "true" ] && FULL_FLAG="true"

    node -e "
      const puppeteer = require('puppeteer');
      (async () => {
        const browser = await puppeteer.launch({ headless: 'new' });
        const page = await browser.newPage();
        await page.setViewport({ width: $WIDTH, height: $HEIGHT });
        await page.goto('$URL', { waitUntil: 'networkidle0', timeout: 30000 });
        await page.screenshot({ path: '$OUTPUT', fullPage: $FULL_FLAG });
        await browser.close();
        console.log('Screenshot saved to $OUTPUT');
      })().catch(e => { console.error(e.message); process.exit(1); });
    " 2>&1
  # Fallback: macOS screencapture with open URL
  else
    echo "Neither playwright nor puppeteer found."
    echo "Install with: npm i -g playwright or npm i puppeteer"
    echo ""
    echo "Alternative: open the URL in a browser and use macOS screencapture"
    echo "  open '$URL'"
    echo "  screencapture -l\$(osascript -e 'tell app \"Safari\" to id of window 1') $OUTPUT"
    exit 1
  fi
workdir: project
timeout: 60
confirm: false
---

Use this tool when the user wants to capture a screenshot of a website for design reference. The screenshot can then be used with image_info to check dimensions or placed into a design as reference. Requires playwright or puppeteer to be installed.
