---
id: optimize_svg
name: Optimize SVG
description: Optimize and clean up SVG path data or SVG files
parameters:
  - name: input
    type: string
    description: SVG path data string (d attribute) or path to an SVG file
    required: true
  - name: precision
    type: string
    description: Decimal precision for coordinates (default 2)
    required: false
command: |
  INPUT={{input}}
  PRECISION={{precision}}

  if [ -z "$PRECISION" ]; then
    PRECISION=2
  fi

  python3 -c "
  import re, sys, os

  input_val = '''$INPUT'''
  precision = int('$PRECISION')

  # Check if it's a file path
  if os.path.isfile(input_val.strip(\"'\")):
      with open(input_val.strip(\"'\"), 'r') as f:
          content = f.read()
      # Extract all d attributes
      paths = re.findall(r'd=\"([^\"]+)\"', content)
      if not paths:
          print('No path data found in SVG file')
          sys.exit(1)
      path_data = paths[0]
      print(f'Source: {input_val} ({len(paths)} path(s))')
  else:
      path_data = input_val.strip(\"'\")

  original_len = len(path_data)

  # Parse path commands
  commands = re.findall(r'([MmLlHhVvCcSsQqTtAaZz])\s*([^MmLlHhVvCcSsQqTtAaZz]*)', path_data)

  optimized = []
  for cmd, args in commands:
      args = args.strip()
      if not args:
          optimized.append(cmd)
          continue

      # Round numbers to precision
      nums = re.findall(r'-?\d+\.?\d*(?:e[+-]?\d+)?', args)
      rounded = []
      for n in nums:
          val = round(float(n), precision)
          # Remove trailing zeros
          if val == int(val):
              rounded.append(str(int(val)))
          else:
              rounded.append(f'{val:.{precision}f}'.rstrip('0').rstrip('.'))

      optimized.append(cmd + ' '.join(rounded))

  result = ''.join(optimized)
  new_len = len(result)
  saved = original_len - new_len
  pct = (saved / original_len * 100) if original_len > 0 else 0

  # Count commands
  cmd_count = len(re.findall(r'[MmLlHhVvCcSsQqTtAaZz]', result))
  point_count = len(re.findall(r'-?\d+\.?\d*', result))

  print(f'')
  print(f'=== Optimized Path ===')
  print(result)
  print(f'')
  print(f'Commands: {cmd_count}')
  print(f'Points: {point_count}')
  print(f'Size: {original_len} → {new_len} chars ({saved} saved, {pct:.1f}% smaller)')
  "
workdir: project
timeout: 10
confirm: false
---

Use this tool to optimize SVG path data before using it in create_design_element. Reduces coordinate precision, removes redundant decimals, and reports path statistics. Can take raw path data (d attribute) or a path to an SVG file.
